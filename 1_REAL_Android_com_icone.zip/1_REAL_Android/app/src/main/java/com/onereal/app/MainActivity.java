package com.onereal.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.view.View;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(21,21,21));
        getWindow().setNavigationBarColor(Color.rgb(21,21,21));
        WebView view = new WebView(this);
        view.setBackgroundColor(Color.rgb(21,21,21));
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(false);
        settings.setDomStorageEnabled(false);
        view.setVerticalScrollBarEnabled(false);
        view.setHorizontalScrollBarEnabled(false);
        setContentView(view);
        view.loadUrl("file:///android_asset/index.html");
    }
}
